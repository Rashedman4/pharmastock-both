import pool from "@/lib/db";
import { NextResponse, NextRequest } from "next/server";
import { revalidatePath } from "next/cache";
import { getToken } from "next-auth/jwt";
import { parsePaginationParams, buildPaginationMeta } from "@/lib/mobile/paginate";

//  GET all signal history
export async function GET(req: NextRequest) {
  const token = await getToken({ req });
  if (!token) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const authorizedEmails = process.env.AUTHORIZED_EMAILS?.split(",") || [];
  if (!authorizedEmails.includes(token.email as string)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { page, limit, offset } = parsePaginationParams(req);

    const [countResult, dataResult] = await Promise.all([
      pool.query("SELECT COUNT(*) FROM signal_history"),
      pool.query(
        `SELECT * FROM signal_history ORDER BY id DESC LIMIT $1 OFFSET $2`,
        [limit, offset]
      ),
    ]);

    const total = parseInt(countResult.rows[0].count, 10);

    return NextResponse.json(
      {
        data: dataResult.rows,
        pagination: buildPaginationMeta(total, page, limit),
      },
      { status: 200 }
    );
  } catch (error) {
    return NextResponse.json(
      { error: "Error fetching signal history: " + error },
      { status: 500 }
    );
  }
}

//  POST new record (manually add to history if needed)
export async function POST(req: NextRequest) {
  const token = await getToken({ req });
  if (!token) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const authorizedEmails = process.env.AUTHORIZED_EMAILS?.split(",") || [];
  if (!authorizedEmails.includes(token.email as string)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const body = await req.json();
    const {
      symbol,
      entrance_date,
      closing_date,
      in_price,
      out_price,
      success,
      reason_en,
      reason_ar,
    } = body;

    const query = `
      INSERT INTO signal_history
        (symbol, entrance_date, closing_date, in_price, out_price, success, reason_en, reason_ar)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      RETURNING *;
    `;

    const result = await pool.query(query, [
      symbol,
      entrance_date,
      closing_date,
      in_price,
      out_price,
      success,
      reason_en,
      reason_ar,
    ]);

    revalidatePath("/api/admin/signalHistory");

    return NextResponse.json(result.rows[0], { status: 201 });
  } catch (error) {
    return NextResponse.json(
      { error: "Error adding to signal history: " + error },
      { status: 500 }
    );
  }
}

//  PUT (edit a history record)
export async function PUT(req: NextRequest) {
  const token = await getToken({ req });
  if (!token) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const authorizedEmails = process.env.AUTHORIZED_EMAILS?.split(",") || [];
  if (!authorizedEmails.includes(token.email as string)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const {
      id,
      symbol,
      entrance_date,
      closing_date,
      in_price,
      out_price,
      success,
      reason_en,
      reason_ar,
    } = await req.json();

    const query = `
      UPDATE signal_history
      SET symbol = $1,
          entrance_date = $2,
          closing_date = $3,
          in_price = $4,
          out_price = $5,
          success = $6,
          reason_en = $7,
          reason_ar = $8
      WHERE id = $9
      RETURNING *;
    `;
    const result = await pool.query(query, [
      symbol,
      entrance_date,
      closing_date,
      in_price,
      out_price,
      success,
      reason_en,
      reason_ar,
      id,
    ]);

    revalidatePath("/api/admin/signalHistory");
    return NextResponse.json(result.rows[0], { status: 200 });
  } catch (error) {
    return NextResponse.json(
      { error: "Error updating signal history: " + error },
      { status: 500 }
    );
  }
}

//  DELETE (remove a record)
export async function DELETE(req: NextRequest) {
  const token = await getToken({ req });
  if (!token) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  const authorizedEmails = process.env.AUTHORIZED_EMAILS?.split(",") || [];
  if (!authorizedEmails.includes(token.email as string)) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }

  try {
    const { id } = await req.json();

    const query = `DELETE FROM signal_history WHERE id = $1`;
    await pool.query(query, [id]);

    revalidatePath("/api/admin/signalHistory");

    return NextResponse.json({ success: true }, { status: 200 });
  } catch (error) {
    return NextResponse.json(
      { error: "Error deleting signal history: " + error },
      { status: 500 }
    );
  }
}
