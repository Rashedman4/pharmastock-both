import { NextRequest, NextResponse } from 'next/server';
import pool from '@/lib/db';
import { getMobileAuthPayload } from '@/lib/mobile/auth-middleware';
import { parsePaginationParams, buildPaginationMeta } from '@/lib/mobile/paginate';
import { refreshSignalPricesIfStale } from '@/modules/market-data/signal-price-refresh.service';

export async function GET(req: NextRequest) {
  const auth = getMobileAuthPayload(req);
  if (!auth) {
    return NextResponse.json(
      { error: { code: 'UNAUTHORIZED', message: 'Valid Bearer token required' } },
      { status: 401 }
    );
  }

  try {
    await refreshSignalPricesIfStale();
    const { page, limit, offset } = parsePaginationParams(req);

    const [countResult, dataResult] = await Promise.all([
      pool.query('SELECT COUNT(*)::int AS total FROM signals'),
      pool.query(
        `SELECT id, symbol, type, enter_price, price_now, first_target, second_target,
                date_opened, reason_en, reason_ar
         FROM signals
         ORDER BY date_opened DESC
         LIMIT $1 OFFSET $2`,
        [limit, offset]
      ),
    ]);

    const total: number = countResult.rows[0].total;

    return NextResponse.json(
      { data: dataResult.rows, pagination: buildPaginationMeta(total, page, limit) },
      { headers: { 'Cache-Control': 'private, max-age=30, stale-while-revalidate=60' } }
    );
  } catch (err) {
    console.error('[signals] GET error', err);
    return NextResponse.json(
      { error: { code: 'INTERNAL_ERROR', message: 'Failed to fetch signals' } },
      { status: 500 }
    );
  }
}
