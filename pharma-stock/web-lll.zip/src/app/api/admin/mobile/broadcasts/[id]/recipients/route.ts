import { NextRequest, NextResponse } from 'next/server';
import { getToken } from 'next-auth/jwt';
import pool from '@/lib/db';
import { parsePaginationParams, buildPaginationMeta } from '@/lib/mobile/paginate';

async function assertAdmin(req: NextRequest) {
  const token = await getToken({ req });
  return token?.role === 'admin' ? token : null;
}

type Ctx = { params: Promise<{ id: string }> };

export async function GET(req: NextRequest, ctx: Ctx) {
  const token = await assertAdmin(req);
  if (!token) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const { id: campaignId } = await ctx.params;
  const { page, limit, offset } = parsePaginationParams(req);

  const [countRes, dataRes] = await Promise.all([
    pool.query(
      'SELECT COUNT(*) FROM broadcast_recipients WHERE campaign_id = $1',
      [campaignId]
    ),
    pool.query(
      `SELECT br.id, br.user_id, br.delivered_at, cm.read_at,
              u.firstname, u.lastname, u.email
       FROM broadcast_recipients br
       LEFT JOIN users u ON u.id = br.user_id
       LEFT JOIN chat_conversations cc ON cc.user_id = br.user_id
       LEFT JOIN chat_messages cm ON cm.broadcast_campaign_id = br.campaign_id
                                  AND cm.conversation_id = cc.id
       WHERE br.campaign_id = $1
       ORDER BY br.id
       LIMIT $2 OFFSET $3`,
      [campaignId, limit, offset]
    ),
  ]);

  const total = parseInt(countRes.rows[0].count, 10);

  return NextResponse.json({
    data: dataRes.rows,
    pagination: buildPaginationMeta(total, page, limit),
  });
}
